function _AwaitValue(value) {
  this.wrapped = value;
}
module.exports = _AwaitValue, module.exports.__esModule = true, module.exports["default"] = module.exports;