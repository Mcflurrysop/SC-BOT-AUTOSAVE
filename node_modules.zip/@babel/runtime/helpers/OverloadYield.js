function _OverloadYield(value, kind) {
  this.v = value, this.k = kind;
}
module.exports = _OverloadYield, module.exports.__esModule = true, module.exports["default"] = module.exports;